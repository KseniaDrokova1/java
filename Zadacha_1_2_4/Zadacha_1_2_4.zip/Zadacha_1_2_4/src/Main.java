public class Main {
    public static void main(String[] args) {
        boolean varboolean = true;
        byte varbyte = 1;
        short varshort = 1000;
        int varint = 100000;
        long varlong = 1000L;
        double vardouble = 3.45;
        float varvloat = 1.31F;
        char varchar = 1;
    }

}